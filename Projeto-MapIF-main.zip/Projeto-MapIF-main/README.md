# Projeto-MapIF
Primeiro protótipo do projeto MapIF da disciplina de Algoritmos e Programação, pretende-se criar um mapa interativo para qualquer estudante recém chegado ao IFPB - Campus Campina Grande, idealização por Ronaldo Urquiza, coworkers: Mariane Oliveira e Carolina Porto.
